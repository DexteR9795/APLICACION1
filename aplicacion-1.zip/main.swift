
var numero:Int;
print("Dime un número: ", terminator:"")
numero = Int(readLine()!)!
// Comprobamos si es par
if numero % 2 == 0 {
  print("\(numero) es par")
}
else {
     print("\(numero) es impar")
}