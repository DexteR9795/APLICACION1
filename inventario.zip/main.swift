
struct Articulo{
var nombre: String
var cantdad: Int

}

func registroArticulo() -> Articulo{
print("Registrar Articulos")
print("Ingresa el nombreIdel articulo")
let nombre = readLine( )!
print("Ingresa la cantidad de exitencia")
let cantidad = Int(readLine()!)!
return Articulo(nombre: nombre, cantdad: cantidad)

}

func mostrarlistado(articulos: [Articulo]){
print("Listado de Articulos")
for(indice, articulo) in articulos.enumerated( ){
print("articulo \(indice + 1): \(articulo.nombre)")
print("Cantidad: \(articulo.cantdad)")

}
}

func consultadeArticulo(articulos: [Articulo]){
print("Consulta de Articulos")
print("Ingresa el nombre del articulo a consultar")
let nombre = readLine( )!
for(indice, articulo) in articulos.enumerated(){
if articulo.nombre == nombre{
print("articulo \(indice + 1): \(articulo.nombre)")
print("Cantidad: \(articulo.cantdad)")
break
 }
}
}
  

var articulo: [Articulo] = []
var opcion = 0
repeat {
print("1 .- Registro")
print("2 .- Listado")
print("3 .- Consulta")
print("4 .- Salir")
print("Seleciiona una opcion")
opcion = (Int(readLine()!))!
switch opcion{
case 1:
print("Registro")
let nuevoArticulo = registroArticulo()
articulo.append(nuevoArticulo)
print("**** Articulo registrado *******")  
case 2:
print("Listado")
mostrarlistado(articulos:articulo)
case 3:
print("Consulta")
consultadeArticulo(articulos:articulo)
case 4:
print("Salir")
default:
print("Opcion invalida")
}
} while opcion != 4

